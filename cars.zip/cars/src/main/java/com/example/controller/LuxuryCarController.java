package com.example.controller;

import java.util.Collection;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.CarDAO;
import com.example.model.Car;

@RestController
public class LuxuryCarController {
	
	@Autowired
	CarDAO carDAO;
	
	@RequestMapping(path = "/API/CAR", method = RequestMethod.POST, consumes= {"application/json"} ,produces = { "text/plain" })
	public String addCar(@RequestBody Car car) {
		System.out.println("Inside CarController.addCar()!!");
		System.out.println(car);
		return "Car added in DB!!";
	}
	
	@RequestMapping(path = "/API/CAR/{vin}", method = RequestMethod.GET, produces = { "application/json" })
	public Car readCarAsJSON(@PathVariable("vin") int vin) {
		System.out.println("Inside CarController.readCarAsJSON()!!");
		return carDAO.selectByVIN(vin);
	}
	
	@RequestMapping(path = "/API/CARS", method = RequestMethod.GET, produces = { "application/json" })
	public Collection<Car> readAllCarsAsJSON() {
		System.out.println("Inside CarController.readAllCarsAsJSON()!!");
		return carDAO.selectAll();
	}
	

	@RequestMapping(path = "/API/CARS", method = RequestMethod.GET, produces = { "application/xml" })
	public Collection<Car> readAllCarsAsXML() {
		System.out.println("Inside CarController.readAllCarsAsXML()!!");
		return carDAO.selectAll();
	}

	@RequestMapping(path = "/API/CAR", method = RequestMethod.GET, produces = { "application/xml" })
	public Car readOneCarAsXML() {
		System.out.println("Inside CarController.readOneCarAsXML()!!");
		return new Car(100, "XE", "Jaguar", 78000000.00);
	}

	@RequestMapping(path = "/API/CAR", method = RequestMethod.GET, produces = { "application/json" })
	public Car readOneCarAsJSON() {
		System.out.println("Inside CarController.readOneCarAsJSON()!!");
		return new Car(100, "XE", "Jaguar", 78000000.00);
	}

}

package com.example.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//@Controller
//@RestController
public class CarController {

	@RequestMapping(path="/API/CAR",method=RequestMethod.GET,produces= {"text/plain"})
	//@ResponseBody
	public String readOneCar() {
		System.out.println("Inside CarController.readOneCar()!!");
		return "VIN : 100, Model : X1, Make : BMW, Price : 2000000.00";
	}
	
	@RequestMapping(path="/API/CAR",method=RequestMethod.GET,produces= {"application/xml"})
	//@ResponseBody
	public String readOneCarAsXML() {
		System.out.println("Inside CarController.readOneCarAsXML()!!");
		return "<car><vin>100</vin><model>X1</model><make>BMW</make><price>2000000.00</price></car>";
	}

	@RequestMapping(path="/API/CAR",method=RequestMethod.GET,produces= {"application/json"})
	//@ResponseBody
	public String readOneCarAsJSON() {
		System.out.println("Inside CarController.readOneCarAsJSON()!!");
		return "{\"vin\":100,\"model\":\"X1\",\"make\":\"BMW\",\"price\":2000000.00}";
	}

}

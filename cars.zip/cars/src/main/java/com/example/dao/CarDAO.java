package com.example.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Repository;

import com.example.model.Car;

@Repository
public class CarDAO {

	Map<Integer,Car> cars = new HashMap<>();
	
	@PostConstruct
	public void init() {
		cars.put(100,new Car(100, "XE", "Jaguar", 7800000.00));
		cars.put(101,new Car(101, "XF", "Jaguar", 4800000.00));
		cars.put(102,new Car(102, "X1", "BMW", 100000.00));
		cars.put(103,new Car(103, "Q5", "Audi", 9000000.00));
		cars.put(104,new Car(104, "Q7", "audi", 1200000.00));
	}
	
	
	public Collection<Car> selectAll() {
		System.out.println("Inside CarDAO.selectAll()!!!!");
		return cars.values();
	}

	public Car selectByVIN(int vin) {
		System.out.println("Inside CarDAO.selectByVIN()!!!!");
		return cars.get(vin);
	}

}

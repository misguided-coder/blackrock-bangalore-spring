package com.example.lifecycle;

public class PayrollService {

	public PayrollService() {
		System.out.println("Inside PayrollService()!!");
	}

	public void init() {
		System.out.println("Inside PayrollService.init()!!");
	}

	public void clacHRA(double basic) {
		System.out.printf("HRA : %s%n", (basic * .40));
	}

	public void clean() {
		System.out.println("Inside PayrollService.clean()!!");
	}

}

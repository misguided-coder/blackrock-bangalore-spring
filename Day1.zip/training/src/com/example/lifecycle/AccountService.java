package com.example.lifecycle;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class AccountService implements InitializingBean,DisposableBean {

	public AccountService() {
		System.out.println("Inside AccountService()!!");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Inside AccountService.afterPropertiesSet()!!");
	}
	
	public void init() {
		System.out.println("Inside AccountService.init()!!");
	}

	public void open(String name) {
		System.out.printf("Account Opened for Mr. %s with 0 balance!!%n", name);
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("Inside AccountService.destroy()!!");
	}
	
	public void clean() {
		System.out.println("Inside AccountService.clean()!!");
	}
}

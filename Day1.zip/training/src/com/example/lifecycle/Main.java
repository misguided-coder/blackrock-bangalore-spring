package com.example.lifecycle;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext(
				"com/example/lifecycle/appCxt.xml");

		PayrollService payrollService = container.getBean("payrollService", PayrollService.class);
		payrollService.clacHRA(20000.00);

		AccountService accountService = container.getBean("accountService", AccountService.class);
		accountService.open("Bill Gates");

		container.close();

	}
}
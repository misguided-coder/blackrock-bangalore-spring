package com.example.factorypostprocessor;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;

public class ContainerPostProcessor implements BeanFactoryPostProcessor{

	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory container) throws BeansException {
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter("container.log",true);
			String message = "Container statup time is : "+LocalDateTime.now();
			fileWriter.write(message);
			fileWriter.write("\n");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if(fileWriter != null)
					fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}

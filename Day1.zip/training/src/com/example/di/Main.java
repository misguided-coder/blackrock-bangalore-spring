package com.example.di;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext("com/example/di/appCxt.xml");
		System.out.println("IoC Container is started!!!!!");

		EmployeeService employeeService = (EmployeeService) container.getBean("employeeService");
		employeeService.add();

		container.close();
		System.out.println("IoC Container is stopped!!!!!");

	}
}
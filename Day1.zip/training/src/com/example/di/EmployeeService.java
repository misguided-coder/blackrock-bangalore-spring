package com.example.di;

/*
 * Service which will have business logic for employee management.
 */
public class EmployeeService {

	String title;
	double version;
	EmployeeDAO employeeDAO;

	public EmployeeService() {
	}

	/*
	 * public EmployeeService(EmployeeDAO employeeDAO) { this.employeeDAO =
	 * employeeDAO; }
	 */

	public EmployeeService(String title) {
		this.title = title;
	}

	public EmployeeService(String title, EmployeeDAO employeeDAO) {
		this.title = title;
		this.employeeDAO = employeeDAO;
	}

	public void setVersion(double version) {
		this.version = version;
	}

	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	public void add() {
		System.out.println("Inside EmployeeService.add()!!!!");
		System.out.printf("Title : %s%n", title);
		System.out.printf("Version : %s%n", version);
		employeeDAO.save();
	}

	public void applyForLeave() {
		System.out.println("Inside EmployeeService.applyForLeave()!!!!");
		employeeDAO.update();
	}

	public void assignProject() {
		System.out.println("Inside EmployeeService.assignProject()!!!!");
		employeeDAO.update();
	}

	public void updateEmail() {
		System.out.println("Inside EmployeeService.updateEmail()!!!!");
		employeeDAO.update();
	}

}

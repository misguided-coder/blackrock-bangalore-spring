package com.example.di;

import java.util.List;

/*
 * DAO which will have DB logic for employee data management
 */
public class EmployeeDAO {

	String[] drivers;
	List<String> languages;

	public void setDrivers(String[] drivers) {
		this.drivers = drivers;
	}

	public void setLanguages(List<String> languages) {
		this.languages = languages;
	}

	public void save() {
		System.out.println("Inside EmployeeDAO.save()!!!!");
		System.out.println("Drivers supported  by DAO!!!!");
		for (String value : drivers) {
			System.out.println(value);
		}
		System.out.printf("Languages supported  by DAO : %s%n",languages);
		// 20 JDBC loc
	}

	public void update() {
		System.out.println("Inside EmployeeDAO.update()!!!!");
		// 20 JDBC loc
	}

	public void delete() {
		System.out.println("Inside EmployeeDAO.delete()!!!!");
		// 20 JDBC loc
	}

}

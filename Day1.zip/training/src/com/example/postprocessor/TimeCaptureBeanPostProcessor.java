package com.example.postprocessor;

import java.time.LocalDateTime;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class TimeCaptureBeanPostProcessor implements BeanPostProcessor {

    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException{
		//50 loc
    	if(bean instanceof AccountService) {
    		return null;
    	} else {
    		System.out.println(bean);
    		System.out.printf("%s created at %s!!%n",beanName,LocalDateTime.now());
    	}
    	return bean;
	}
	
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException{
  		//50 loc
    	return bean;
  	}
}

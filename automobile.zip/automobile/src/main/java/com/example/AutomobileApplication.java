package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/*@EnableAutoConfiguration
@ComponentScan("com.example.controller")
@Configuration*/

@SpringBootApplication(scanBasePackages="com.example")
public class AutomobileApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomobileApplication.class, args);
	}

	@Bean
	public int unique() {
		return (int) (Math.random() * 5000);
	}

	@Bean
	public String company() {
		return "BlackRock Inc.";
	}

}

package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class FunController {
	
	@Autowired
	@Qualifier("company")
	String companyName;

	@RequestMapping(path="/fun")
	@ResponseBody
	public String haveSomeFun() {
		System.out.println("Inside FunController.haveSomeFun()!!");
		return "Training will finish at 11 PM and We work at "+companyName;
	}
	
}

package com.example.dao;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Repository;

@Repository
public class WeatherDAO {

	Map<String, Integer> info;

	@PostConstruct
	public void init() {
		info = new HashMap<>();
		info.put("Delhi", 35);
		info.put("Bangalore", 20);
		info.put("Hyderabad", 28);
		info.put("Pune", 25);
	}

	public Map<String, Integer> selectAll() {
		// DB call
		System.out.println("Inside WeatherDAO.selectAll()!!");
		return info;
	}

	public int selectWeatherByCity(String cityName) {
		// DB call
		System.out.println("Inside WeatherDAO.selectWeatherByCity()!!");
		return info.get(cityName);
	}

	@PreDestroy
	public void clean() {
		info.clear();
		info = null;
	}

}

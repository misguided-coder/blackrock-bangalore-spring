package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.service.WeatherService;

@Controller
public class WeatherController {
	
	@Autowired
	WeatherService weatherService;

	@RequestMapping(path="/weather/city",method=RequestMethod.GET)
	public ModelAndView handleRequestForCity(
			@RequestParam("city") String cityName,
			@RequestParam("day") String day) {
		
		System.out.println("Inside WeatherController.handleRequestForCity()!!");
		int currentWeather = weatherService.readWeatherByCity(cityName);
		String message = cityName+" temp is "+currentWeather+" deg on "+day+ " day!!!!";
		ModelAndView modelAndView = new ModelAndView("weather", "WEATHERINFO", message);
		return modelAndView; 
	}
	
	
	/*@RequestMapping(path="/weather/city")
	public ModelAndView handleRequestForCity(@RequestParam("city") String cityName) {
		System.out.println("Inside WeatherController.handleRequestForCity()!!");
		int currentWeather = weatherService.readWeatherByCity(cityName);
		String message = cityName+" temp is "+currentWeather+" deg.";
		ModelAndView modelAndView = new ModelAndView("weather", "WEATHERINFO", message);
		return modelAndView; 
	}*/
	
	
	/*@RequestMapping(path="/weather/city")
	public ModelAndView handleRequestForCity(HttpServletRequest request) {
		System.out.println("Inside WeatherController.handleRequestForCity()!!");
		String cityName = request.getParameter("city");
		int currentWeather = weatherService.readWeatherByCity(cityName);
		String message = cityName+" temp is "+currentWeather+" deg.";
		ModelAndView modelAndView = new ModelAndView("weather", "WEATHERINFO", message);
		return modelAndView; 
	}*/
	
	/*@RequestMapping(path="/weather/city")
	public ModelAndView handleRequestForCity(HttpServletRequest request) {
		System.out.println("Inside WeatherController.handleRequestForCity()!!");
		String cityName = request.getParameter("city");
		String message = cityName+" temp is 20 deg.";
		ModelAndView modelAndView = new ModelAndView("weather", "WEATHERINFO", message);
		return modelAndView; 
	}*/

	/*@RequestMapping(path="/weather/city")
	public ModelAndView handleRequestForCity() {
		System.out.println("Inside WeatherController.handleRequestForCity()!!");
		ModelAndView modelAndView = new ModelAndView("weather", "WEATHERINFO", "Bangalore temp is 24 deg.");
		return modelAndView; //logical view name and model data
	}*/
	
	@RequestMapping(path="/weather")
	public String handleRequest() {
		System.out.println("Inside WeatherController.handleRequest()!!");
		return "weather"; //logical view name and no model data
	}
}

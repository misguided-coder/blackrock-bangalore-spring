package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/user")
public class UserController {

	@RequestMapping(path="/form",method=RequestMethod.GET)
	public String showForm() {
		System.out.println("Inside UserController.showForm()!!");
		return "userForm"; 
	}

	@RequestMapping(path="/register",method=RequestMethod.POST)
	public String register(String name,String phone,String email) {
		System.out.println("Inside UserController.register()!!");
		System.out.printf("Name : %s%n",name);
		System.out.printf("Phone : %s%n",phone);
		System.out.printf("Email : %s%n",email);
		return "success"; 
	}
}

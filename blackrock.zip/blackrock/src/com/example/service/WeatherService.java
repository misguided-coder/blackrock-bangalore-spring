package com.example.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.WeatherDAO;

@Service
public class WeatherService {

	@Autowired
	WeatherDAO weatherDAO;

	public Map<String, Integer> readAll() {
		System.out.println("Inside WeatherService.readAll()!!");
		return weatherDAO.selectAll();
	}

	public int readWeatherByCity(String cityName) {
		System.out.println("Inside WeatherService.readWeatherByCity()!!");
		return weatherDAO.selectWeatherByCity(cityName);
	}

}

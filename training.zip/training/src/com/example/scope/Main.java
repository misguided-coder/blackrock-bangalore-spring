package com.example.scope;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext("com/example/scope/appCxt.xml");
	
		
		//User 1
		PayrollService payrollService1 = container.getBean("payrollService",PayrollService.class);
		System.out.println(payrollService1);
		System.out.println(payrollService1.hashCode());
		
		payrollService1.clacHRA(20000.00);
		
		//User 2
		PayrollService payrollService2 = container.getBean("payrollService",PayrollService.class);
		System.out.println(payrollService2);
		System.out.println(payrollService2.hashCode());
		payrollService2.clacHRA(40000.00);
		
		
		container.close();
	
	}
}
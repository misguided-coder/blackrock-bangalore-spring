package com.example.factorypostprocessor;

public class AccountService  {

	public AccountService() {
		System.out.println("Inside AccountService()!!");
	}

	public void open(String name) {
		System.out.printf("Account Opened for Mr. %s with 0 balance!!%n", name);
	}

}

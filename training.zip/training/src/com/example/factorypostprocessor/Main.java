package com.example.factorypostprocessor;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext(
				"com/example/factorypostprocessor/appCxt.xml");
		
		AccountService accountService = container.getBean("accountService", AccountService.class);
		accountService.open("Bill Gates");
		
		CalculatorService calculatorService = container.getBean("calculatorService",CalculatorService.class);
		calculatorService.sum(10, 5);
		calculatorService.diff(10, 5);

		PayrollService payrollService = container.getBean("payrollService", PayrollService.class);
		payrollService.clacHRA(20000.00);

		container.close();

	}
}
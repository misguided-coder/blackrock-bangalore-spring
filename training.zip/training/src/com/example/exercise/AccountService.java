package com.example.exercise;

public interface AccountService  {
	public abstract void open(String name);
}

package com.example.exercise;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BranchService {
	
	@Autowired
	AccountService savingsAccountService;

	@Autowired
	AccountService currentAccountService;

	public void openAccount(String type,String name) {
		System.out.println("Branch Manager is opening account!!");
		if(type.equals("S"))
			savingsAccountService.open(name);
		else if(type.equals("C"))
			currentAccountService.open(name);
		
	}
	
}

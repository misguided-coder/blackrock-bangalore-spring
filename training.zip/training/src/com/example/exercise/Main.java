package com.example.exercise;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext(AppConfig.class);
		
		BranchService branchService = container.getBean("branchService",BranchService.class);

		branchService.openAccount("S","Raju");
		branchService.openAccount("C","Jaggu");
		
		container.close();
	}
}
package com.example.exercise;

import org.springframework.stereotype.Service;

@Service("currentAccountService")
public class CurrentAccountServiceImpl implements AccountService {

	public void open(String name) {
		System.out.printf("Current account opened for Mr %s%n", name);
	}
}

package com.example.exercise;

import org.springframework.stereotype.Service;

@Service("savingsAccountService")
public class SavingsAccountServiceImpl implements AccountService {

	public void open(String name) {
		System.out.printf("Saving account opened for Mr %s%n", name);
	}

}

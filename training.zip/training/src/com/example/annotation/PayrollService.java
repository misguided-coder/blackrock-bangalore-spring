package com.example.annotation;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

@Component
public class PayrollService {

	public PayrollService() {
		System.out.println("Inside PayrollService()!!");
	}

	@PostConstruct
	public void init() {
		System.out.println("Inside PayrollService.init()!!");
	}

	public void clacHRA(double basic) {
		System.out.printf("HRA : %s%n", (basic * .40));
	}


	@PreDestroy
	public void clean() {
		System.out.println("Inside PayrollService.clean()!!");
	}

}

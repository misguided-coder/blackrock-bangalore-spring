package com.example.annotation;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext(
				"com/example/annotation/appCxt.xml");

		/*CalculatorService calculatorService = container.getBean("calculatorService", CalculatorService.class);
		calculatorService.sum(10, 5);
		calculatorService.diff(10, 5);
		 */
		
		container.close();
	}
}
package com.example.annotation.di;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDAO employeeDAO;

	/*
	 * public EmployeeService() {
	 * System.out.println("Inside EmployeeService()!!!!"); }
	 */

	/*
	 * @Autowired public EmployeeService(EmployeeDAO employeeDAO) {
	 * System.out.println("Inside EmployeeService(EmployeeDAO employeeDAO)!!!!");
	 * this.employeeDAO = employeeDAO; }
	 */

	/*public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		System.out.println("Inside setEmployeeDAO(EmployeeDAO employeeDAO)!!!!");
		this.employeeDAO = employeeDAO;
	}*/

	public void add() {
		System.out.println("Inside EmployeeService.add()!!!!");
		employeeDAO.save();
	}

	public void applyForLeave() {
		System.out.println("Inside EmployeeService.applyForLeave()!!!!");
		employeeDAO.update();
	}

	public void assignProject() {
		System.out.println("Inside EmployeeService.assignProject()!!!!");
		employeeDAO.update();
	}

	public void updateEmail() {
		System.out.println("Inside EmployeeService.updateEmail()!!!!");
		employeeDAO.update();
	}

}

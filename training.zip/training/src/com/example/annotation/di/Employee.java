package com.example.annotation.di;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Employee {

	//@Value("1001")
	@Value("#{sequenceGenerator.generate() + 5000}") //Spring 3.0
	int id;

	@Value("${user.app.name}")
	String name;

	@Value("35")
	int age;

	@Value("10-10-2010")
	String dob;

	Map<String, Address> addresses;

	// Set<Address> addresses;

	// List<Address> addresses;

	// public Address[] addresses;

	// public Address home;
	// public Address office;

	/*
	 * Address address;
	 * 
	 * public Address getAddress() { return address; }
	 */

	/*
	 * @Autowired public void setAddress(Address address) { this.address = address;
	 * }
	 */

	// @Autowired
	// @Qualifier("luxuryAddress")
	/*
	 * public void write(Address address) { this.address = address; }
	 */

	/*
	 * @Autowired public void write(@Qualifier("homeAddress") Address
	 * address1, @Qualifier("officeAddress")Address address2) { this.home =
	 * address1; this.office = address2; }
	 */

	/*
	 * @Autowired public void write(Address homeAddress, Address officeAddress) {
	 * this.home = homeAddress; this.office = officeAddress; }
	 */

	/*
	 * @Autowired public void write(Address[] addresses) { this.addresses =
	 * addresses; }
	 */

	/*
	 * @Autowired public void write(List<Address> addresses) { this.addresses =
	 * addresses; }
	 */

	/*
	 * @Autowired public void write(Set<Address> addresses) { this.addresses =
	 * addresses; }
	 */

	@Autowired
	public void write(Map<String, Address> addresses) {
		this.addresses = addresses;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + ", dob=" + dob + ", addresses=" + addresses
				+ "]";
	}

}

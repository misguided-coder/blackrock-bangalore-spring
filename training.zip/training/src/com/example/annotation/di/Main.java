package com.example.annotation.di;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext(
				"com/example/annotation/di/appCxt.xml");

		EmployeeService employeeService = container.getBean("employeeService", EmployeeService.class);
		employeeService.add();
		
		Employee employee = container.getBean("employee", Employee.class);
		//System.out.println(employee.getAddress());
		//System.out.println(employee.home);
		//System.out.println(employee.office);
		
		/*for(Address address : employee.addresses) {
			System.out.println(address);
		}*/
		
		System.out.println(employee);
		System.out.println(employee.addresses);
		
		container.close();

	}
}
package com.example.annotation.di;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class SequenceGenerator {

	public int generate() {
		return (int)(Math.random()*5000);
	}
	
}

package com.example.annotation.di;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDAO {
	
	public EmployeeDAO() {
		System.out.println("Inside EmployeeDAO()!!!!");
	}

	public void save() {
		System.out.println("Inside EmployeeDAO.save()!!!!");
		// 20 JDBC loc
	}

	public void update() {
		System.out.println("Inside EmployeeDAO.update()!!!!");
		// 20 JDBC loc
	}

	public void delete() {
		System.out.println("Inside EmployeeDAO.delete()!!!!");
		// 20 JDBC loc
	}

}

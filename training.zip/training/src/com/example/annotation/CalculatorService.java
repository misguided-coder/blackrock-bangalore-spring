package com.example.annotation;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
@Lazy
public class CalculatorService {
	
	public CalculatorService() {
		System.out.println("Inside CalculatorService()!!");
	}

	public void sum(int i,int j) {
		System.out.printf("SUM : %s%n",(i+j));
	}

	public void diff(int i,int j) {
		System.out.printf("DIFF : %s%n",(i-j));
	}
}
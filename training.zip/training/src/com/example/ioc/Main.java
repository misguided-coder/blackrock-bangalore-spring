package com.example.ioc;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		// IoC Container is started
		ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext("com/example/ioc/appCxt.xml");
		System.out.println("IoC Container is started!!!!!");

		Calculator calculator = (Calculator) container.getBean("calculator");
		calculator.sum(10, 5);
		calculator.diff(10, 5);

		// IoC Container is stopped
		container.close();
		System.out.println("IoC Container is stopped!!!!!");

	}
}
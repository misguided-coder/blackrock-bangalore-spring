package com.example.property.file;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext(
				"com/example/property/file/appCxt.xml");

		GreetService greetService = container.getBean("greetService",GreetService.class);
		
		greetService.greet("Jaggu");
		
		container.close();
	}
}
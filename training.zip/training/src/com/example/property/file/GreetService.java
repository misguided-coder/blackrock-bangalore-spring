package com.example.property.file;

public class GreetService {

	String greeting;

	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}

	public void greet(String name) {
		System.out.printf("%s Mr. %s%n", greeting, name);
	}

}

package com.example.postprocessor;

public class PayrollService {

	public PayrollService() {
		System.out.println("Inside PayrollService()!!");
	}

	public void clacHRA(double basic) {
		System.out.printf("HRA : %s%n", (basic * .40));
	}

}

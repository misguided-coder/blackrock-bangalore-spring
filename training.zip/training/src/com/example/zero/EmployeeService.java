package com.example.zero;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

	@Autowired
	@Qualifier("currentDate")
	String todayDate;
	
	@Autowired
	@Qualifier("sequence")
	long empId;
	
	@Autowired
	@Qualifier("employeeInfo")
	Map<String, Double> employees;

	public EmployeeService() {
		System.out.println("Inside EmployeeService()!!");
	}

	public void display() {
		System.out.printf("Todays Date is : %s%n", todayDate);
		System.out.printf("Employee ID : %s%n", empId);
		System.out.printf("All Employees Info : %s%n", employees);
	}

}

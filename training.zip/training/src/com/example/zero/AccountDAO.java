package com.example.zero;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

@Repository
public class AccountDAO {

	@Value("${jdbc.driver}")
	String driver;
	
	@Value("${jdbc.url}")
	String url;
	
	public AccountDAO() {
		System.out.println("Inside AccountDAO()!!");
	}

	@PostConstruct
	public void init() {
		System.out.printf("DB connection ready using %s dirver and %s url!!%n",driver,url);
	}
	
	public void save() {
		System.out.println("Inside AccountDAO.save()!!");
	}

	@PreDestroy
	public void clean() {
		System.out.printf("DB connection released!!");
	}
	
}

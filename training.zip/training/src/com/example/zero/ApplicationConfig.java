package com.example.zero;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

@Configuration
public class ApplicationConfig {

	// @Bean(initMethod="init",destroyMethod="clean")
	@Bean
	@Scope("singleton")
	@Lazy
	public AccountService accountService() {
		return new AccountService();
	}

	@Bean
	public AccountDAO accountDAO() {
		return new AccountDAO();
	}

}

package com.example.zero;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService  {

	@Autowired
	AccountDAO accountDAO;
	
	public AccountService() {
		System.out.println("Inside AccountService()!!");
	}
	
	@PostConstruct
	public void init() {
		System.out.println("Inside AccountService.init()!!");
	}

	public void open(String name) {
		System.out.printf("Account Opened for Mr. %s with 0 balance!!%n", name);
		accountDAO.save();
	}
	
	@PreDestroy
	public void clean() {
		System.out.println("Inside AccountService.clean()!!");
	}

}

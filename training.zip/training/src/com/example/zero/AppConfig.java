package com.example.zero;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Configuration
@ComponentScan("com.example.zero")
public class AppConfig {

	@Bean
	public PropertyPlaceholderConfigurer loadProperties() {
		Resource resource = new ClassPathResource("com/example/zero/application.properties");
		PropertyPlaceholderConfigurer propertyPlaceholderConfigurer = new PropertyPlaceholderConfigurer();
		propertyPlaceholderConfigurer.setLocation(resource);
		return propertyPlaceholderConfigurer;
	}

	@Bean
	public String currentDate() {
		Date date = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
		String value = simpleDateFormat.format(date);
		return value;
	}

	@Bean
	public long sequence() {
		Runtime runtime = Runtime.getRuntime();
		return (long) (Math.random() * runtime.availableProcessors() * runtime.freeMemory() * runtime.totalMemory()
				* 5000);
	}

	@Bean
	public Map<String, Double> employeeInfo() {
		Map<String, Double> info = new HashMap<>();
		info.put("Jaggu", 120000.00);
		info.put("Pintu", 670000.00);
		info.put("Chandu", 340000.00);
		info.put("Ghanshu", 80000.00);
		return info;
	}

}

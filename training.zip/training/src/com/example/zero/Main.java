package com.example.zero;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {

		// AnnotationConfigApplicationContext container = new
		// AnnotationConfigApplicationContext(ApplicationConfig.class);

		AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext(AppConfig.class);

		// USer 1
		AccountService accountService1 = container.getBean("accountService", AccountService.class);
		System.out.println(accountService1);
		accountService1.open("Raj");

		// USer 2
		AccountService accountService2 = container.getBean("accountService", AccountService.class);
		System.out.println(accountService2);
		accountService2.open("Raj");
		
		EmployeeService employeeService = container.getBean("employeeService", EmployeeService.class);
		employeeService.display();

		container.close();
	}
}